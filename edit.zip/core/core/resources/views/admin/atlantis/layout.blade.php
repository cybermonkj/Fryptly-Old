@include('admin.atlantis.header')

@yield('content')

@include('admin.atlantis.footer')