<?php
    $st = App\site_settings::find(1);
?>
<!DOCTYPE html>
<html>
<head>
	<title>Registration Confirmation</title>
</head>
<body>
    <div class="row">
        <div class="col-sm-4"></div>
        <div class="col-sm-4" style="border:1px solid #CCC; padding:5%; ">
            <div align="">

        	</div>
        	<h3 align="">Hi {{$md['usr']}}, </h3>
        	<p>
        	    You've taken a bold step for signing up at <a href="https://{{env('MAIL_SENDER')}}"><b>Fryptly</b></a><br>
        		To complete your registration and begin earning on Fryptly, please click the link below to activate your account. and make a deposite, invest now<br>
        		<a class="btn btn-info" href="http://{{env('MAIL_SENDER')}}/registration/confirm/{{$md['usr']}}/{{$md['token']}}"><b>Confirm Registration</b></a>
        	</p>
        	<p>
        		<i class="fa fa-certificate"></i>Thanks for registering at {{env('MAIL_SENDER')}}. Giantsec cares!
        	</p>
        </div>
    </div>
	
</body>
</html>
