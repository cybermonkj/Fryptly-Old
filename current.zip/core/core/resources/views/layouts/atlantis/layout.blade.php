@include('layouts.atlantis.header')
@yield('content')
@include('layouts.atlantis.footer')